# How to start

To run the project:

### `npm start`


Please note that the back end should run on port **8080** by default.
API connection will be made to *http://localhost:8080/api*

# Demo video
https://drive.google.com/file/d/1V3WTwzLdBCC3WRq2aKyNbCfBncTqIuia/view?usp=drive_link
